package com.chepegallego.chppagos

import android.app.Activity
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object Alarmas {
    private const val PREF = "alarmas"

    fun reemplazar(c: Context, j: String) {
        val sp = c.getSharedPreferences(PREF, 0)
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val viejo = JSONArray(sp.getString("lista", "[]"))
        for (i in 0 until viejo.length()) am.cancel(pi(c, viejo.getJSONObject(i)))
        sp.edit().putString("lista", j).apply()
        programarTodas(c)
    }

    fun programarTodas(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val lista = JSONArray(c.getSharedPreferences(PREF, 0).getString("lista", "[]"))
        val ahora = System.currentTimeMillis()
        var cambio = false
        for (i in 0 until lista.length()) {
            val o = lista.getJSONObject(i)
            var t = o.optLong("t")
            if (o.optBoolean("diario") && t <= ahora) {
                while (t <= ahora) t += 86400000L
                o.put("t", t); cambio = true
            }
            if (t <= ahora) continue
            val p = pi(c, o)
            try {
                if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms())
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
                else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            } catch (e: SecurityException) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t, p)
            }
        }
        if (cambio) c.getSharedPreferences(PREF, 0).edit().putString("lista", lista.toString()).apply()
    }

    fun marcarToma(c: Context, clave: String) {
        val sp = c.getSharedPreferences("tomas", 0)
        val a = JSONArray(sp.getString("hechas", "[]"))
        a.put(clave)
        while (a.length() > 400) a.remove(0)
        sp.edit().putString("hechas", a.toString()).apply()
    }

    fun tomasHechas(c: Context): String = c.getSharedPreferences("tomas", 0).getString("hechas", "[]") ?: "[]"

    private fun pi(c: Context, o: JSONObject): PendingIntent {
        val i = Intent(c, AvisoReceiver::class.java)
            .putExtra("titulo", o.optString("titulo"))
            .putExtra("texto", o.optString("texto"))
            .putExtra("id", o.optInt("id"))
            .putExtra("toma", o.optString("toma"))
        return PendingIntent.getBroadcast(c, o.optInt("id"), i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}

class AvisoReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val titulo = i.getStringExtra("titulo") ?: "ChpPagos"
        val texto = i.getStringExtra("texto") ?: ""
        val id = i.getIntExtra("id", 0)
        val toma = i.getStringExtra("toma") ?: ""
        Alarmas.programarTodas(c)
        val nm = c.getSystemService(NotificationManager::class.java)
        val canal = NotificationChannel("avisos", "Avisos de pagos", NotificationManager.IMPORTANCE_HIGH)
        canal.setSound(RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM),
            AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build())
        nm.createNotificationChannel(canal)
        val full = Intent(c, AvisoActivity::class.java)
            .putExtra("titulo", titulo).putExtra("texto", texto).putExtra("toma", toma)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pf = PendingIntent.getActivity(c, id, full,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(c, "avisos")
            .setSmallIcon(R.drawable.ic_aviso)
            .setContentTitle(titulo)
            .setContentText(texto)
            .setStyle(Notification.BigTextStyle().bigText(texto))
            .setCategory(Notification.CATEGORY_ALARM)
            .setFullScreenIntent(pf, true)
            .setContentIntent(pf)
            .setAutoCancel(true)
            .build()
        try { nm.notify(id, n) } catch (e: SecurityException) { }
    }
}

class ArranqueReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { Alarmas.programarTodas(c) }
}

class AvisoActivity : Activity() {
    private var tono: Ringtone? = null
    private var tts: TextToSpeech? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val titulo = intent.getStringExtra("titulo") ?: ""
        val texto = intent.getStringExtra("texto") ?: ""
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.WHITE)
            setPadding(48, 140, 48, 48)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        col.addView(TextView(this).apply {
            text = titulo; textSize = 32f; setTextColor(Color.BLACK)
            typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        })
        col.addView(TextView(this).apply {
            text = texto; textSize = 26f; setTextColor(Color.BLACK)
            gravity = Gravity.CENTER; setPadding(0, 60, 0, 60)
        })
        val toma = intent.getStringExtra("toma") ?: ""
        if (toma.isNotEmpty()) {
            col.addView(Button(this).apply {
                text = "✅ Ya me los tomé"; textSize = 28f
                setOnClickListener {
                    val f = java.text.SimpleDateFormat("yyyy-MM-dd", Locale.US).format(java.util.Date())
                    Alarmas.marcarToma(this@AvisoActivity, "$f $toma")
                    finish()
                }
            })
        }
        col.addView(Button(this).apply {
            text = if (toma.isNotEmpty()) "Después" else "Entendido"; textSize = 28f
            setOnClickListener { finish() }
        })
        setContentView(col)
        tono = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
        tono?.play()
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFinishing) return@postDelayed
            tono?.stop()
            tts = TextToSpeech(this) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("es", "CO")
                    tts?.speak("$titulo. $texto", TextToSpeech.QUEUE_FLUSH, null, "aviso")
                }
            }
        }, 8000)
    }

    override fun onDestroy() {
        tono?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
