package com.chepegallego.chppagos

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import java.util.Locale

object Gps {
    @SuppressLint("MissingPermission")
    fun pedir(c: Context, fin: (String) -> Unit) {
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val prov = when {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            else -> { fin("apagado"); return }
        }
        var listo = false
        val ultimo: Location? = try { lm.getLastKnownLocation(prov) } catch (e: Exception) { null }
        fun dar(l: Location?) {
            if (listo) return
            listo = true
            fin(if (l == null) "" else String.format(Locale.US, "%.6f,%.6f", l.latitude, l.longitude))
        }
        val escucha = object : LocationListener {
            override fun onLocationChanged(l: Location) { lm.removeUpdates(this); dar(l) }
            override fun onProviderEnabled(p: String) {}
            override fun onProviderDisabled(p: String) {}
            @Deprecated("Solo para Android viejo")
            override fun onStatusChanged(p: String?, s: Int, e: Bundle?) {}
        }
        try {
            lm.requestLocationUpdates(prov, 0L, 0f, escucha, Looper.getMainLooper())
        } catch (e: Exception) {
            dar(ultimo)
            return
        }
        Handler(Looper.getMainLooper()).postDelayed({
            try { lm.removeUpdates(escucha) } catch (e: Exception) { }
            dar(ultimo)
        }, 20000)
    }
}
