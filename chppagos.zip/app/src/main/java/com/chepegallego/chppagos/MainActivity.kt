package com.chepegallego.chppagos

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private var cbFoto: String? = null
    private var cbZip: String? = null
    private var cbGps: String? = null
    private var impresora: WebView? = null

    private val escaner = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        devolver(r.data?.getStringExtra("foto") ?: "")
    }
    private val galeria = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri == null) {
            devolver("")
        } else {
            Thread {
                val n = try { Fotos.desdeUri(this, uri) } catch (e: Exception) { "" }
                runOnUiThread { devolver(n) }
            }.start()
        }
    }
    private val zipEntrada = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val cb = cbZip ?: return@registerForActivityResult
        cbZip = null
        if (uri == null) { js("$cb('')"); return@registerForActivityResult }
        Thread {
            val r = try { Paquetes.leer(this, uri) } catch (e: Exception) { "" }
            js("$cb(${JSONObject.quote(r)})")
        }.start()
    }
    private val permiso = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val permisoGps = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r.values.any { it }) tomarGps() else darGps("")
    }

    private fun devolver(n: String) {
        val cb = cbFoto ?: return
        cbFoto = null
        js("$cb(${JSONObject.quote(n)})")
    }

    private fun darGps(t: String) {
        val cb = cbGps ?: return
        cbGps = null
        js("$cb(${JSONObject.quote(t)})")
    }

    private fun tomarGps() = Gps.pedir(this) { t -> darGps(t) }

    fun js(c: String) = runOnUiThread { web.evaluateJavascript(c, null) }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.textZoom = 100
        web.addJavascriptInterface(Puente(), "Android")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, req: WebResourceRequest): WebResourceResponse? {
                val u = req.url
                if (u.host != "app.local") return null
                val p = (u.path ?: "/").trimStart('/')
                return try {
                    if (p.startsWith("foto/")) {
                        val f = File(Fotos.dirInterno(this@MainActivity), p.removePrefix("foto/"))
                        WebResourceResponse("image/webp", null, FileInputStream(f))
                    } else {
                        val a = if (p.isEmpty()) "index.html" else p
                        val mime = when {
                            a.endsWith(".html") -> "text/html"
                            a.endsWith(".js") -> "application/javascript"
                            a.endsWith(".css") -> "text/css"
                            a.endsWith(".webp") -> "image/webp"
                            else -> "application/octet-stream"
                        }
                        WebResourceResponse(mime, "utf-8", assets.open(a))
                    }
                } catch (e: Exception) {
                    WebResourceResponse("text/plain", "utf-8", 404, "No", mapOf(), "".byteInputStream())
                }
            }
        }
        web.loadUrl("https://app.local/index.html")
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            permiso.launch(Manifest.permission.POST_NOTIFICATIONS)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("atras()") { r -> if (r != "true") finish() }
            }
        })
    }

    inner class Puente {
        private val ctx: Activity get() = this@MainActivity

        @Suppress("DEPRECATION")
        @JavascriptInterface fun version(): String =
            try { packageManager.getPackageInfo(packageName, 0).versionName ?: "" } catch (e: Exception) { "" }

        @JavascriptInterface fun cargar(): String = Datos.cargar(ctx)
        @JavascriptInterface fun guardar(j: String) = Datos.guardar(ctx, j)

        @JavascriptInterface fun escanear(modo: String, cb: String) {
            cbFoto = cb
            runOnUiThread { escaner.launch(Intent(ctx, EscanerActivity::class.java).putExtra("modo", modo)) }
        }

        @JavascriptInterface fun deGaleria(cb: String) {
            cbFoto = cb
            runOnUiThread { galeria.launch("image/*") }
        }

        @JavascriptInterface fun gps(cb: String) {
            cbGps = cb
            runOnUiThread {
                val fino = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val grueso = checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                if (fino || grueso) tomarGps()
                else permisoGps.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }

        @JavascriptInterface fun programar(j: String) = Alarmas.reemplazar(ctx, j)

        @JavascriptInterface fun copiar(t: String) {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("ChpPagos", t))
        }

        @JavascriptInterface fun llamar(n: String) {
            runOnUiThread { startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$n"))) }
        }

        @JavascriptInterface fun mapa(lat: String, lon: String, nombre: String) {
            runOnUiThread {
                val u = Uri.parse("geo:$lat,$lon?q=$lat,$lon(" + Uri.encode(nombre) + ")")
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (e: Exception) { }
            }
        }

        @JavascriptInterface fun borrarFoto(n: String) = Fotos.borrar(ctx, n)

        @JavascriptInterface fun crearPaquete(correo: String, leeme: String, biblioteca: String, fotos: String): String {
            return try { Paquetes.crear(ctx, correo, leeme, biblioteca, fotos) } catch (e: Exception) { "" }
        }

        @JavascriptInterface fun cargarRespuesta(cb: String) {
            cbZip = cb
            runOnUiThread { zipEntrada.launch("*/*") }
        }

        @JavascriptInterface fun imprimir(html: String, nombre: String) {
            runOnUiThread {
                val w = WebView(ctx)
                impresora = w
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, url: String) {
                        val pm = getSystemService(Context.PRINT_SERVICE) as android.print.PrintManager
                        pm.print(nombre, v.createPrintDocumentAdapter(nombre),
                            android.print.PrintAttributes.Builder()
                                .setMediaSize(android.print.PrintAttributes.MediaSize.NA_LETTER).build())
                    }
                    override fun shouldInterceptRequest(v: WebView, req: WebResourceRequest): WebResourceResponse? =
                        web.webViewClient.shouldInterceptRequest(v, req)
                }
                w.loadDataWithBaseURL("https://app.local/", html, "text/html", "utf-8", null)
            }
        }
    }
}
