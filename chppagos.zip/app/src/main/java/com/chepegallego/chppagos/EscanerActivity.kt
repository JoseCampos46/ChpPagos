package com.chepegallego.chppagos

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PointF
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.os.SystemClock
import android.util.Size
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Magnifier
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

class EscanerActivity : ComponentActivity(), SensorEventListener {
    private lateinit var raiz: FrameLayout
    private lateinit var vista: PreviewView
    private lateinit var nivel: NivelView
    private lateinit var estado: TextView
    private lateinit var botonFlash: Button
    private var captura: ImageCapture? = null
    private var proveedor: ProcessCameraProvider? = null
    private var sensores: SensorManager? = null
    private var flash = true
    private var modo = "fac"
    private val esDoc get() = modo != "prod" && modo != "tienda"
    private var gx = 0f
    private var gy = 0f
    private var desdeNivel = 0L
    private var ultimoToque = 0L
    private var tocando = false
    private var disparando = false
    private var enRecorte = false
    private var estabaNivel = false
    private val pito: ToneGenerator? by lazy { try { ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80) } catch (e: Exception) { null } }

    private val permiso = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) iniciarCamara() else finish()
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        modo = intent.getStringExtra("modo") ?: "fac"
        flash = getSharedPreferences("escaner", 0).getBoolean("flash", true)
        sensores = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        armarCamara()
        if (checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) iniciarCamara()
        else permiso.launch(Manifest.permission.CAMERA)
    }

    private fun boton(t: String, accion: () -> Unit) = Button(this).apply {
        text = t; textSize = 17f; isAllCaps = false
        setOnClickListener { accion() }
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
    }

    private fun armarCamara() {
        enRecorte = false
        disparando = false
        raiz = FrameLayout(this)
        vista = PreviewView(this)
        raiz.addView(vista, FrameLayout.LayoutParams(-1, -1))
        nivel = NivelView(this, if (esDoc) 0.08f else 0.04f)
        raiz.addView(nivel, FrameLayout.LayoutParams(-1, -1))
        estado = TextView(this).apply {
            textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(0xCC000000.toInt())
            gravity = Gravity.CENTER; setPadding(16, 24, 16, 24)
            text = if (esDoc) "Ponga la factura o el recibo dentro del recuadro" else "Ponga el producto dentro del recuadro"
        }
        raiz.addView(estado, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val barra = LinearLayout(this).apply { setBackgroundColor(0xCC000000.toInt()); setPadding(8, 8, 8, 8) }
        botonFlash = boton(textoFlash()) {
            flash = !flash
            getSharedPreferences("escaner", 0).edit().putBoolean("flash", flash).apply()
            botonFlash.text = textoFlash()
        }
        barra.addView(botonFlash)
        barra.addView(boton("Tomar ya") { disparar() })
        barra.addView(boton("Cancelar") { finish() })
        raiz.addView(barra, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(raiz)
    }

    private fun textoFlash() = if (flash) "Flash: sí" else "Flash: no"

    private fun iniciarCamara() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val prov = f.get()
            proveedor = prov
            val prev = Preview.Builder().build().also { it.setSurfaceProvider(vista.surfaceProvider) }
            val cap = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(ResolutionSelector.Builder().setResolutionStrategy(
                    ResolutionStrategy(Size(2400, 1800), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
                ).build())
                .build()
            captura = cap
            try {
                prov.unbindAll()
                prov.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, prev, cap)
            } catch (e: Exception) {
                estado.text = "No se pudo abrir la cámara"
            }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onResume() {
        super.onResume()
        sensores?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensores?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        sensores?.unregisterListener(this)
    }

    override fun onDestroy() {
        pito?.release()
        super.onDestroy()
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        tocando = ev.actionMasked != MotionEvent.ACTION_UP && ev.actionMasked != MotionEvent.ACTION_CANCEL
        ultimoToque = SystemClock.uptimeMillis()
        return super.dispatchTouchEvent(ev)
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        if (enRecorte) return
        gx = gx * 0.8f + e.values[0] * 0.2f
        gy = gy * 0.8f + e.values[1] * 0.2f
        val inclinado = hypot(gx, gy)
        val aNivel = inclinado < 0.55f
        val ahora = SystemClock.uptimeMillis()
        nivel.mover(gx, -gy, aNivel)
        if (aNivel && !estabaNivel) { desdeNivel = ahora; pito?.startTone(ToneGenerator.TONE_PROP_BEEP, 120) }
        estabaNivel = aNivel
        if (disparando) return
        when {
            tocando || ahora - ultimoToque < 900 -> estado.text = "Suelte la pantalla para disparar"
            !aNivel -> estado.text = "Ponga el celular derecho: la bolita al centro"
            ahora - desdeNivel < 1000 -> estado.text = "Quieto…"
            else -> disparar()
        }
    }

    private fun disparar() {
        val cap = captura ?: return
        if (disparando) return
        disparando = true
        estado.text = "OK ✓ tomando la foto"
        estado.setBackgroundColor(0xEE0F6E56.toInt())
        cap.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        cap.takePicture(ContextCompat.getMainExecutor(this), object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(img: ImageProxy) {
                val giro = img.imageInfo.rotationDegrees.toFloat()
                val b = img.toBitmap()
                img.close()
                mostrarRecorte(Fotos.rotar(Fotos.escalar(b, 2400), giro))
            }

            override fun onError(e: ImageCaptureException) {
                disparando = false
                estado.setBackgroundColor(0xCC000000.toInt())
                estado.text = "No se pudo tomar. Intente otra vez"
            }
        })
    }

    private fun mostrarRecorte(bmp: Bitmap) {
        enRecorte = true
        proveedor?.unbindAll()
        val caja = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val rec = RecorteView(this, bmp, if (esDoc) 0.06f else 0.0f)
        caja.addView(rec, FrameLayout.LayoutParams(-1, -1))
        val aviso = TextView(this).apply {
            textSize = 18f; setTextColor(Color.WHITE); setBackgroundColor(0xCC000000.toInt())
            gravity = Gravity.CENTER; setPadding(12, 16, 12, 16)
            text = "Mueva las esquinas verdes. La lupa le muestra el borde"
        }
        caja.addView(aviso, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        val barra = LinearLayout(this).apply { setBackgroundColor(0xCC000000.toInt()); setPadding(8, 8, 8, 8) }
        barra.addView(boton("Repetir") { armarCamara(); iniciarCamara() })
        barra.addView(boton("Toda la foto") { rec.todo() })
        barra.addView(boton("Listo ✓") {
            aviso.text = "Guardando…"
            Thread {
                val n = Fotos.guardar(this, rec.recortar(), modo)
                runOnUiThread {
                    setResult(RESULT_OK, Intent().putExtra("foto", n))
                    finish()
                }
            }.start()
        })
        caja.addView(barra, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        setContentView(caja)
    }
}

class NivelView(c: Context, private val margen: Float) : View(c) {
    private var bx = 0f
    private var by = 0f
    private var ok = false
    private val d = c.resources.displayMetrics.density
    private val marco = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 4 * d }
    private val bola = Paint(Paint.ANTI_ALIAS_FLAG)

    fun mover(x: Float, y: Float, nivelado: Boolean) { bx = x; by = y; ok = nivelado; invalidate() }

    override fun onDraw(cv: Canvas) {
        val col = if (ok) Color.rgb(29, 158, 117) else Color.WHITE
        marco.color = col
        val mx = width * margen
        val my = height * (margen + 0.08f)
        cv.drawRect(mx, my, width - mx, height - my, marco)
        val cx = width / 2f
        val cy = height / 2f
        val r = 46 * d
        cv.drawCircle(cx, cy, r, marco)
        val k = r / 3f
        val px = cx + max(-r, min(r, bx * k))
        val py = cy + max(-r, min(r, by * k))
        bola.color = if (ok) Color.rgb(29, 158, 117) else Color.rgb(239, 159, 39)
        cv.drawCircle(px, py, 14 * d, bola)
    }
}

@SuppressLint("ViewConstructor")
class RecorteView(c: Context, private val bmp: Bitmap, margen: Float) : View(c) {
    private val p = Array(4) { PointF() }
    private var esc = 1f
    private var ox = 0f
    private var oy = 0f
    private var activo = -1
    private val d = c.resources.displayMetrics.density
    private val lupa = Magnifier(this)
    private val linea = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 3 * d; color = Color.rgb(29, 158, 117)
    }
    private val punto = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(29, 158, 117) }

    init { poner(margen) }

    private fun poner(m: Float) {
        val mx = bmp.width * m
        val my = bmp.height * m
        p[0].set(mx, my); p[1].set(bmp.width - mx, my)
        p[2].set(bmp.width - mx, bmp.height - my); p[3].set(mx, bmp.height - my)
    }

    fun todo() { poner(0f); invalidate() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        esc = min(w.toFloat() / bmp.width, h.toFloat() / bmp.height)
        ox = (w - bmp.width * esc) / 2f
        oy = (h - bmp.height * esc) / 2f
    }

    private fun aPantalla(q: PointF) = PointF(ox + q.x * esc, oy + q.y * esc)

    override fun onDraw(cv: Canvas) {
        cv.drawBitmap(bmp, null, RectF(ox, oy, ox + bmp.width * esc, oy + bmp.height * esc), null)
        val s = p.map { aPantalla(it) }
        val camino = Path().apply {
            moveTo(s[0].x, s[0].y); lineTo(s[1].x, s[1].y); lineTo(s[2].x, s[2].y); lineTo(s[3].x, s[3].y); close()
        }
        cv.drawPath(camino, linea)
        s.forEach { cv.drawCircle(it.x, it.y, 13 * d, punto) }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                activo = -1
                var mejor = 60 * d
                p.forEachIndexed { i, q ->
                    val s = aPantalla(q)
                    val dd = hypot(s.x - e.x, s.y - e.y)
                    if (dd < mejor) { mejor = dd; activo = i }
                }
            }
            MotionEvent.ACTION_MOVE -> if (activo >= 0) {
                val x = max(0f, min(bmp.width.toFloat(), (e.x - ox) / esc))
                val y = max(0f, min(bmp.height.toFloat(), (e.y - oy) / esc))
                p[activo].set(x, y)
                val s = aPantalla(p[activo])
                lupa.show(s.x, s.y)
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { activo = -1; lupa.dismiss() }
        }
        return true
    }

    fun recortar(): Bitmap {
        fun dist(a: PointF, b: PointF) = hypot(a.x - b.x, a.y - b.y)
        val w = max(dist(p[0], p[1]), dist(p[3], p[2])).coerceAtLeast(10f)
        val h = max(dist(p[0], p[3]), dist(p[1], p[2])).coerceAtLeast(10f)
        val out = Bitmap.createBitmap(w.toInt(), h.toInt(), Bitmap.Config.ARGB_8888)
        val m = Matrix()
        m.setPolyToPoly(
            floatArrayOf(p[0].x, p[0].y, p[1].x, p[1].y, p[2].x, p[2].y, p[3].x, p[3].y), 0,
            floatArrayOf(0f, 0f, w, 0f, w, h, 0f, h), 0, 4)
        Canvas(out).apply { drawColor(Color.WHITE); drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG)) }
        return out
    }
}
