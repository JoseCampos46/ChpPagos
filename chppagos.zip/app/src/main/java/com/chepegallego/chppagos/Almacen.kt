package com.chepegallego.chppagos

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.os.Build
import android.os.Environment
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Carpeta {
    fun base(sub: String = ""): File {
        val d = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            if (sub.isEmpty()) "ChpPagos" else "ChpPagos/$sub")
        if (!d.exists()) d.mkdirs()
        return d
    }
}

object Datos {
    fun cargar(c: Context): String {
        val f = File(c.filesDir, "datos.json")
        if (f.exists()) return f.readText()
        return try {
            val e = File(Carpeta.base(), "datos.json")
            if (e.exists()) e.readText() else ""
        } catch (x: Exception) { "" }
    }

    fun guardar(c: Context, j: String) {
        File(c.filesDir, "datos.json").writeText(j)
        try { File(Carpeta.base(), "datos.json").writeText(j) } catch (x: Exception) { }
    }
}

object Fotos {
    fun dirInterno(c: Context): File = File(c.filesDir, "fotos").apply { mkdirs() }

    @Suppress("DEPRECATION")
    private fun formato(): Bitmap.CompressFormat =
        if (Build.VERSION.SDK_INT >= 30) Bitmap.CompressFormat.WEBP_LOSSY else Bitmap.CompressFormat.WEBP

    fun escalar(b: Bitmap, max: Int): Bitmap {
        val m = maxOf(b.width, b.height)
        if (m <= max) return b
        val k = max.toFloat() / m
        return Bitmap.createScaledBitmap(b, (b.width * k).toInt(), (b.height * k).toInt(), true)
    }

    fun rotar(b: Bitmap, g: Float): Bitmap =
        if (g == 0f) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(g) }, true)

    fun guardar(c: Context, original: Bitmap, prefijo: String): String {
        val nitida = prefijo == "fac" || prefijo == "rec" || prefijo == "lot" || prefijo == "pago"
        val bmp = escalar(original, if (nitida) 2400 else 1400)
        val n = prefijo + "_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".webp"
        val f = File(dirInterno(c), n)
        FileOutputStream(f).use { bmp.compress(formato(), if (nitida) 82 else 70, it) }
        FileOutputStream(File(dirInterno(c), "t_$n")).use { escalar(bmp, 320).compress(formato(), 60, it) }
        try { f.copyTo(File(Carpeta.base("fotos"), n), true) } catch (e: Exception) { }
        return n
    }

    fun desdeUri(c: Context, u: Uri): String {
        val op = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        c.contentResolver.openInputStream(u)!!.use { BitmapFactory.decodeStream(it, null, op) }
        var s = 1
        while (maxOf(op.outWidth, op.outHeight) / (s * 2) >= 2400) s *= 2
        val b = c.contentResolver.openInputStream(u)!!.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: throw IllegalStateException("sin imagen")
        val giro = try {
            c.contentResolver.openInputStream(u)!!.use {
                when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                    6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f
                }
            }
        } catch (e: Exception) { 0f }
        return guardar(c, rotar(b, giro), "fac")
    }

    fun borrar(c: Context, n: String) {
        File(dirInterno(c), n).delete()
        File(dirInterno(c), "t_$n").delete()
    }
}
