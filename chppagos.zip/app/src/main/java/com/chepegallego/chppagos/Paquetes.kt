package com.chepegallego.chppagos

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Paquetes {
    /** Arma el paquete para Claude en Descargas/ChpPagos/Claude/Enviados y devuelve el nombre del archivo. */
    fun crear(c: Context, correo: String, leeme: String, biblioteca: String, fotos: String): String {
        val n = "ChpPagos_" + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".zip"
        val dir = Carpeta.base("Claude/Enviados")
        val f = File(dir, n)
        ZipOutputStream(FileOutputStream(f)).use { z ->
            z.putNextEntry(ZipEntry("LEEME_CLAUDE.txt")); z.write(leeme.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("correo.json")); z.write(correo.toByteArray()); z.closeEntry()
            z.putNextEntry(ZipEntry("biblioteca_actual.json")); z.write(biblioteca.toByteArray()); z.closeEntry()
            val arr = JSONArray(fotos)
            for (i in 0 until arr.length()) {
                val nombre = arr.getString(i)
                val ff = File(Fotos.dirInterno(c), nombre)
                if (!ff.exists()) continue
                z.putNextEntry(ZipEntry("fotos/$nombre"))
                ff.inputStream().use { it.copyTo(z) }
                z.closeEntry()
            }
        }
        return n
    }

    /** Lee la respuesta de Claude: un .zip con biblioteca.json (y fotos) o un .json suelto. */
    fun leer(c: Context, u: Uri): String {
        val bytes = c.contentResolver.openInputStream(u)!!.use { it.readBytes() }
        val esZip = bytes.size > 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()
        if (!esZip) {
            val t = bytes.toString(Charsets.UTF_8)
            JSONObject(t)
            return t
        }
        var json = ""
        ZipInputStream(bytes.inputStream()).use { z ->
            var e = z.nextEntry
            while (e != null) {
                val nombre = e.name.substringAfterLast('/')
                when {
                    e.isDirectory -> {}
                    nombre.endsWith(".json") -> {
                        val t = z.readBytes().toString(Charsets.UTF_8)
                        if (json.isEmpty() || nombre.startsWith("biblioteca")) json = t
                    }
                    nombre.endsWith(".webp") || nombre.endsWith(".jpg") || nombre.endsWith(".png") -> {
                        val b = z.readBytes()
                        val bmp = BitmapFactory.decodeByteArray(b, 0, b.size)
                        if (bmp != null) guardarCon(c, bmp, nombre.substringBeforeLast('.') + ".webp")
                    }
                }
                e = z.nextEntry
            }
        }
        if (json.isEmpty()) throw IllegalStateException("sin json")
        JSONObject(json)
        return json
    }

    private fun guardarCon(c: Context, b: android.graphics.Bitmap, n: String) {
        @Suppress("DEPRECATION")
        val fmt = if (android.os.Build.VERSION.SDK_INT >= 30) android.graphics.Bitmap.CompressFormat.WEBP_LOSSY
        else android.graphics.Bitmap.CompressFormat.WEBP
        val g = Fotos.escalar(b, 2400)
        FileOutputStream(File(Fotos.dirInterno(c), n)).use { g.compress(fmt, 80, it) }
        FileOutputStream(File(Fotos.dirInterno(c), "t_$n")).use { Fotos.escalar(g, 320).compress(fmt, 60, it) }
    }
}
