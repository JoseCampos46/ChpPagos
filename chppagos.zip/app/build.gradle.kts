plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val numero = (System.getenv("GITHUB_RUN_NUMBER") ?: "1").toInt()
android {
    namespace = "com.chepegallego.chppagos"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.chepegallego.chppagos"
        minSdk = 28
        targetSdk = 34
        versionCode = numero
        versionName = "ChpPagos v$numero"
    }
    signingConfigs {
        create("fija") {
            storeFile = file("chppagos.keystore")
            storePassword = "chppagos2026"
            keyAlias = "chppagos"
            keyPassword = "chppagos2026"
        }
    }
    buildTypes {
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("fija") }
        getByName("debug") { signingConfig = signingConfigs.getByName("fija") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    val cx = "1.3.4"
    implementation("androidx.camera:camera-core:$cx")
    implementation("androidx.camera:camera-camera2:$cx")
    implementation("androidx.camera:camera-lifecycle:$cx")
    implementation("androidx.camera:camera-view:$cx")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
}
